declare module "@salesforce/apex/BookingCreateController.retriveBookingInfo" {
  export default function retriveBookingInfo(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/BookingCreateController.getAvailableEmployee" {
  export default function getAvailableEmployee(param: {bkngdt: any}): Promise<any>;
}
declare module "@salesforce/apex/BookingCreateController.saveAppointment" {
  export default function saveAppointment(param: {recordId: any, data: any, jdEmployeeIDs: any}): Promise<any>;
}
declare module "@salesforce/apex/BookingCreateController.retriveMapInfo" {
  export default function retriveMapInfo(param: {recordId: any}): Promise<any>;
}
